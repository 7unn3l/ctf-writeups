import subprocess


def run_code(code: bytes) -> bool:
    rv = subprocess.run(["./yap"], input=code, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env={})

    return rv.returncode == 0


def main():
    print("Welcome to the advanced printf testing service!")
    code = input("Please give me your format to test:")[:4096].strip().encode('ASCII')

    n = 5
    for i in range(n):
        if run_code(code):
            print(f"Attempt {i+1}/{n}: SUCCESS")
        else:
            print(f"Attempt {i+1}/{n}: FAILED")
            exit(1)

    print("Congratulations!")
    with open("flag.txt") as fin:
        print(fin.read())


if __name__ == '__main__':
    main()
